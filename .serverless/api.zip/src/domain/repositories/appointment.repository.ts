export abstract class IAppointmentRepository {
  constructor() {}

  abstract getAllAppointments(): Promise<any[]>;

  abstract getAppointment(): Promise<any>;

  abstract createAppointment(appointment: any): Promise<any>;

  abstract updateAppointment(): Promise<any>;

  abstract removeAppointment(): Promise<any>;
}
