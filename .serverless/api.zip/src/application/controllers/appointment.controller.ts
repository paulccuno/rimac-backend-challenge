import { Body, Controller, Delete, Get, Post, Put } from '@nestjs/common';
import { GetAllAppointmentsHandler } from 'src/domain/handlers/appointment/get-all-appointments.handler';
import { CreateAppointmentRequestDto } from '../dto/appointment/create-appointment.dto';
import { CreateAppointmentHandler } from 'src/domain/handlers/appointment/create-appointment.handler';

@Controller('appointments')
export class AppointmentController {
  constructor(
    private getAllAppointmentsHandler: GetAllAppointmentsHandler,
    private readonly createAppointmentHandler: CreateAppointmentHandler,
  ) {}

  @Get()
  public async getAllAppointments() {
    return await this.getAllAppointmentsHandler.handler();
  }

  @Get('s')
  public async getAppointment() {
    return 'Get an Appointment';
  }

  @Post()
  public async createAppointment(
    @Body() createAppointmentDto: CreateAppointmentRequestDto,
  ) {
    return await this.createAppointmentHandler.handler(createAppointmentDto);
  }

  @Put()
  public async updateAppointment() {
    return 'Update an Appointment';
  }

  @Delete()
  public async removeAppointment() {
    return 'Remove an Appointment';
  }
}
