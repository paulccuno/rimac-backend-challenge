import { Injectable } from '@nestjs/common';
import { CreateAppointmentRequestDto } from 'src/application/dto/appointment/create-appointment.dto';
import { IAppointmentRepository } from 'src/domain/repositories/appointment.repository';

@Injectable()
export class CreateAppointmentHandler {
  constructor(private readonly appointmentRepository: IAppointmentRepository) {}

  public async handler(
    appointment: CreateAppointmentRequestDto,
  ): Promise<string> {
    return this.appointmentRepository.createAppointment(appointment);
  }
}
